"""
The 'higher intelligence' layer.

This module can analyze with Anthropic or Gemini. Set either:
    ANTHROPIC_API_KEY=...
    GEMINI_API_KEY=...

Optional:
    LLM_PROVIDER=auto|anthropic|gemini
"""

import json
import os
import re
from urllib.parse import urlsplit, urlunsplit

import requests
from anthropic import Anthropic, AnthropicError
from dotenv import load_dotenv

from config import GEMINI_MODEL, LLM_MODEL, LLM_PROVIDER, MAX_TOKENS

load_dotenv()

SYSTEM_PROMPT = """You are a disciplined trading analyst. You are given
technical indicators and market context for an asset. Your job is to produce
a cautious, well-reasoned trade signal - NOT to be bullish or bearish by default.

Rules:
- Weigh technicals (RSI, MACD, volatility, price action) AND market context together.
- For crypto, fear/greed sentiment matters directly. For equities, treat broad
  market context as a supporting input and lean more heavily on price action.
- If signals conflict, say so explicitly and lower your confidence rather than
  forcing a directional call.
- Never recommend more than moderate confidence unless multiple independent
  signals agree (e.g. RSI + MACD + market context all pointing the same way).
- Always give an invalidation condition - the price level or indicator flip
  that would prove this call wrong.
- You are not certain of the future. Frame this as probabilistic analysis,
  not prediction.

Respond ONLY with valid JSON, no markdown fences, no preamble, matching this
exact schema:
{
  "signal": "BUY" | "SELL" | "HOLD",
  "confidence": "low" | "medium" | "high",
  "reasoning": "2-3 sentences explaining the call, referencing specific indicator values",
  "fomo_fear_note": "1 sentence on whether crowd psychology or market context supports or contradicts the technical picture",
  "invalidation": "specific price level or condition that would flip this call"
}"""


def build_user_prompt(symbol: str, technicals: dict, sentiment_note: str,
                      market_name: str = "crypto") -> str:
    return f"""Symbol: {symbol}
Market: {market_name}

TECHNICALS:
- Last close: {technicals['last_close']}
- RSI(14): {technicals['rsi']} (trend: {technicals['rsi_trend']})
- MACD line: {technicals['macd']}, Signal line: {technicals['macd_signal']}, Histogram: {technicals['macd_histogram']}
- MACD crossover just now: {technicals['macd_crossover']}
- Volatility (rolling stdev of returns): {technicals['volatility_pct']}%
- Price change over last 24 candles: {technicals['price_change_24_candles_pct']}%
- Recent candle shapes: {technicals['recent_candles']}

MARKET CONTEXT:
{sentiment_note}

Analyze this and produce your signal."""


def configured_provider() -> str | None:
    requested = os.getenv("LLM_PROVIDER", LLM_PROVIDER).strip().lower()
    has_anthropic = bool(os.getenv("ANTHROPIC_API_KEY"))
    has_gemini = bool(os.getenv("GEMINI_API_KEY"))

    if requested == "anthropic":
        return "anthropic" if has_anthropic else None
    if requested == "gemini":
        return "gemini" if has_gemini else None
    if has_anthropic:
        return "anthropic"
    if has_gemini:
        return "gemini"
    return None


def provider_status() -> str:
    provider = configured_provider()
    if provider:
        return provider
    return "missing: set ANTHROPIC_API_KEY or GEMINI_API_KEY"


def auth_present_for(provider: str) -> bool:
    """Whether the relevant credential env var is a non-empty string.
    Never returns or logs the secret itself."""
    if provider == "anthropic":
        return bool(os.getenv("ANTHROPIC_API_KEY"))
    if provider == "gemini":
        return bool(os.getenv("GEMINI_API_KEY"))
    return False


def require_auth() -> str:
    """Call once at startup, before scanning anything.

    Prints the resolved provider and whether its credential is present
    (never the secret value), and fails fast with a clear error instead
    of letting every symbol quietly fall back to HOLD.
    """
    provider = configured_provider()
    print(f"[llm_analyzer] Configured LLM provider: {provider or 'NONE'}")

    if provider is None:
        raise SystemExit(
            "No LLM credentials found. Set ANTHROPIC_API_KEY or GEMINI_API_KEY "
            "in your .env (see _env.example) before running a scan."
        )

    present = auth_present_for(provider)
    print(f"[llm_analyzer] {provider} credential present: {present}")

    if not present:
        raise SystemExit(
            f"Provider resolved to '{provider}' but its API key env var is "
            f"empty. Check your .env file and working directory."
        )

    return provider


def parse_json_response(text: str) -> dict:
    cleaned = text.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
        if not match:
            raise
        return json.loads(match.group(0))


def safe_error_message(error: Exception) -> str:
    message = str(error)
    message = re.sub(r"([?&]key=)[^&\s]+", r"\1[redacted]", message)
    message = re.sub(r"(GEMINI_API_KEY=)[^\s]+", r"\1[redacted]", message)
    message = re.sub(r"(ANTHROPIC_API_KEY=)[^\s]+", r"\1[redacted]", message)
    return message


def gemini_model_candidates() -> list[str]:
    preferred = os.getenv("GEMINI_MODEL", GEMINI_MODEL).strip()
    fallbacks = ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro"]
    candidates = []
    for model in [preferred, *fallbacks]:
        if model and model not in candidates:
            candidates.append(model)
    return candidates

def analyze_with_anthropic(user_prompt: str) -> dict:
    client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
    response = client.messages.create(
        model=os.getenv("ANTHROPIC_MODEL", LLM_MODEL),
        max_tokens=MAX_TOKENS,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_prompt}],
    )
    text = "".join(block.text for block in response.content if block.type == "text").strip()
    return parse_json_response(text)


def analyze_with_gemini(user_prompt: str) -> dict:
    api_key = os.getenv("GEMINI_API_KEY")
    payload = {
        "systemInstruction": {
            "parts": [{"text": SYSTEM_PROMPT}],
        },
        "contents": [{
            "role": "user",
            "parts": [{"text": user_prompt}],
        }],
        "generationConfig": {
            "temperature": 0.2,
            "maxOutputTokens": MAX_TOKENS,
            "responseMimeType": "application/json",
        },
    }

    last_error = None
    for model in gemini_model_candidates():
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        response = requests.post(url, params={"key": api_key}, json=payload, timeout=45)
        if response.status_code == 404:
            last_error = RuntimeError(f"Gemini model not found or unavailable: {model}")
            continue
        try:
            response.raise_for_status()
            data = response.json()
            parts = data["candidates"][0]["content"].get("parts", [])
            text = "".join(part.get("text", "") for part in parts).strip()
            result = parse_json_response(text)
            result["model"] = model
            return result
        except Exception as error:
            last_error = error
            break

    raise RuntimeError(safe_error_message(last_error or RuntimeError("Gemini request failed")))


def analyze(symbol: str, technicals: dict, sentiment_note: str,
            market_name: str = "crypto") -> dict:
    """Calls the configured LLM and returns a parsed signal dict.

    Auth/config problems are NOT swallowed here - call require_auth() once
    at startup so those fail loudly before any symbol is scanned. This
    function only converts genuine post-auth runtime failures (timeouts,
    rate limits, malformed model output, etc.) into a safe HOLD.
    """
    provider = configured_provider()
    if provider is None:
        # require_auth() should have caught this already; treat as fatal
        # rather than quietly returning HOLD for every symbol.
        raise RuntimeError("No LLM API key found. Set ANTHROPIC_API_KEY or GEMINI_API_KEY in .env.")

    user_prompt = build_user_prompt(symbol, technicals, sentiment_note, market_name)

    try:
        if provider == "anthropic":
            result = analyze_with_anthropic(user_prompt)
        else:
            result = analyze_with_gemini(user_prompt)

        result["symbol"] = symbol
        result["provider"] = provider
        return result

    except AnthropicError as e:
        # Auth/config-level failure (e.g. key not resolved by the SDK).
        # This is systemic, not per-symbol - fail fast instead of masking
        # it as a HOLD signal for every asset in the scan.
        raise RuntimeError(
            f"Anthropic authentication/config error: {safe_error_message(e)}"
        ) from e

    except Exception as e:
        # Genuine post-auth model/runtime failure - safe to fall back.
        return {
            "symbol": symbol,
            "signal": "HOLD",
            "confidence": "low",
            "reasoning": f"Analysis failed, defaulting to HOLD for safety: {safe_error_message(e)}",
            "fomo_fear_note": "n/a",
            "invalidation": "n/a",
            "provider": provider,
        }

